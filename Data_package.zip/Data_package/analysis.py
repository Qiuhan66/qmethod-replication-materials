"""Read Data.xlsx, analyse the existing Q sorts, and refresh Results.xlsx and SVG figures."""
from pathlib import Path
import json
import math
import sys
import numpy as np
import pandas as pd
from scipy.stats import norm
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import font_manager
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter


ROOT = Path(__file__).resolve().parent
SHEET_MAP = {'participants': 'Participants', 'q_statements': 'Statements', 'q_sorts': 'QSorts', 'preparatory_participants': 'PreparatoryParticipants', 'statement_development': 'StatementDevelopment', 'interview_turns': 'Interviews', 'quoted_excerpts': 'SelectedQuotes', 'data_dictionary': 'Dictionary'}
RESULT_MAP = {'summary': 'Summary', 'factor_loadings': 'FactorLoadings', 'factor_arrays': 'FactorArrays', 'pairwise_statement_tests': 'PairwiseTests', 'eigenvalues': 'Eigenvalues', 'alternative_solutions': 'AlternativeSolutions', 'factor_array_correlations': 'ArrayCorrelations', 'array_sensitivity': 'ArraySensitivity'}
GRID = np.repeat(np.arange(-4, 5), [2, 3, 4, 6, 10, 6, 4, 3, 2])



def load_data():
    # Read the source workbook without changing it; identifiers link the sheets.
    path = ROOT / 'Data.xlsx'
    if not path.exists():
        raise ValueError('Place analysis.py and Data.xlsx in the same folder.')
    frames = pd.read_excel(path, sheet_name=None, engine='openpyxl', keep_default_na=False)
    data = {key: frames[name] for key, name in SHEET_MAP.items()}
    sorts = data['q_sorts']
    participants = data['participants']
    statements = data['q_statements']
    for name, frame, key in [('QSorts', sorts, 'participant_id'), ('Participants', participants, 'participant_id'), ('Statements', statements, 'statement_id')]:
        if frame[key].eq('').any() or frame[key].duplicated().any():
            raise ValueError(f'{name}: blank or duplicate {key}.')
    ids = [f'S{i:02d}' for i in range(1, 41)]
    if set(statements['statement_id']) != set(ids) or set(sorts.columns) != {'participant_id', *ids}:
        raise ValueError('QSorts and Statements must contain S01–S40 exactly once.')
    if set(sorts.participant_id) != set(participants.participant_id):
        raise ValueError('Participant identifiers do not match between Participants and QSorts.')
    # Sorting by identifiers makes the calculation independent of worksheet row order.
    x = sorts.set_index('participant_id').sort_index()[ids]
    X = x.to_numpy(dtype=float)
    if X.shape[0] < 7 or not np.isfinite(X).all():
        raise ValueError('At least seven complete, finite Q sorts are required.')
    for participant_id, row in zip(x.index, X):
        if not np.array_equal(np.sort(row), GRID):
            raise ValueError(f'{participant_id}: invalid Q-sort distribution; expected counts 2,3,4,6,10,6,4,3,2 for ranks -4 to +4.')
    return x, data

def analyse(x):
    # Standardise each person's sort and analyse the between-person correlation matrix.
    X = x.to_numpy(float)
    N, M = X.shape
    slots = GRID
    tables = {}
    Z = (X - X.mean(1, keepdims=True)) / X.std(1, ddof=0, keepdims=True)
    R = Z @ Z.T / M
    ev, U = np.linalg.eigh(R)
    ix = np.argsort(ev)[::-1]
    ev = ev[ix]
    U = U[:, ix]

    # Rotate PCA loadings using varimax; Kaiser normalisation is applied in solve().
    def varimax(A, gamma=1.0, q=500, tol=1e-09):
        p, k = A.shape
        T = np.eye(k)
        old = 0
        for _ in range(q):
            B = A @ T
            u, s, v = np.linalg.svd(A.T @ (B ** 3 - gamma / p * B @ np.diag(np.diag(B.T @ B))))
            T = u @ v
            val = s.sum()
            if old and val / old < 1 + tol:
                break
            old = val
        return A @ T
    threshold = norm.ppf(0.995) / np.sqrt(M)

    # A defining sort needs one significant loading and a squared loading larger than all others combined.
    def solve(k):
        A = U[:, :k] * np.sqrt(ev[:k])
        h = np.sqrt((A * A).sum(1))
        L = varimax(A / h[:, None]) * h[:, None]
        for j in range(k):
            if L[:, j].sum() < 0:
                L[:, j] *= -1
        L = L[:, np.argsort(-(L * L).sum(0))]
        sig = np.abs(L) > threshold
        flag = sig & (sig.sum(1)[:, None] == 1) & (L * L > (L * L).sum(1)[:, None] - L * L)
        arr = []
        zs = []
        ns = []
        se = []
        for j in range(k):
            ii = np.where(flag[:, j])[0]
            ns.append(len(ii))
            w = L[ii, j] / (1 - L[ii, j] ** 2)
            z = (Z[ii] * w[:, None]).sum(0) / np.abs(w).sum() if len(ii) else np.zeros(M)
            z = (z - z.mean()) / z.std() if z.std() else z
            a = np.empty(M, int)
            a[np.argsort(z, kind='stable')] = slots
            arr.append(a)
            zs.append(z)
            rel = len(ii) * 0.8 / (1 + (len(ii) - 1) * 0.8) if len(ii) else 0
            se.append(np.sqrt(1 - rel))
        return (L, flag, np.array(zs).T, np.array(arr).T, ns, np.array(se))
    # Compare 2–6 factors, without treating numerical fit as an automatic selection rule.
    solutions = []
    for k in range(2, 7):
        L, F, z, a, ns, se = solve(k)
        solutions.append({'factors': k, 'variance_percent': float((L * L).sum() / N * 100), 'defining_counts': ns, 'defined': int(F.any(1).sum()), 'multiple_significant': int(((np.abs(L) > threshold).sum(1) > 1).sum()), 'no_significant': int(((np.abs(L) > threshold).sum(1) == 0).sum())})
    # Keep the supplied four-factor solution and its variance-based factor ordering.
    k = 4
    L, F, z, a, ns, se = solve(k)
    if min(ns) < 2:
        raise ValueError('Each retained factor needs at least two defining sorts for the sensitivity calculation.')
    cols = [f'F{i + 1}' for i in range(k)]
    lf = pd.DataFrame(L, index=x.index, columns=cols)
    for j, c in enumerate(cols):
        lf[c + '_defining'] = F[:, j]
    lf['status'] = ['defining' if f.any() else 'confounded' if (np.abs(l) > threshold).sum() > 1 else 'unassigned' if (np.abs(l) > threshold).sum() == 0 else 'not_defining' for l, f in zip(L, F)]
    tables['factor_loadings'] = lf.reset_index()
    fa = pd.DataFrame({'statement_id': x.columns})
    for j, c in enumerate(cols):
        fa[c + '_z'] = z[:, j]
        fa[c + '_rank'] = a[:, j]
    # Compare factor z scores using standard errors based on the .80 reliability assumption.
    pair = []
    for s in range(M):
        for i in range(k):
            for j in range(i + 1, k):
                sed = np.sqrt(se[i] ** 2 + se[j] ** 2)
                stat = abs(z[s, i] - z[s, j]) / sed
                pair.append([x.columns[s], cols[i], cols[j], z[s, i] - z[s, j], sed, 2 * norm.sf(stat)])
    pairs = pd.DataFrame(pair, columns=['statement_id', 'factor_a', 'factor_b', 'difference_z', 'SED', 'p'])
    tables['pairwise_statement_tests'] = pairs
    for j, c in enumerate(cols):
        vals = []
        for s in x.columns:
            pp = pairs[(pairs.statement_id == s) & ((pairs.factor_a == c) | (pairs.factor_b == c))].p
            vals.append('**' if (pp < 0.01).all() else '*' if (pp < 0.05).all() else '')
        fa[c + '_distinguishing'] = vals
    fa['consensus_p05'] = [bool((pairs[pairs.statement_id == s].p >= 0.05).all()) for s in x.columns]
    tables['factor_arrays'] = fa
    tables['eigenvalues'] = pd.DataFrame({'component': np.arange(1, N + 1), 'eigenvalue': ev})
    tables['alternative_solutions'] = pd.DataFrame(solutions)
    tables['factor_array_correlations'] = pd.DataFrame(np.corrcoef(z.T), index=pd.Index(cols, name='factor'), columns=cols).reset_index()
    # Omit one defining sort at a time, holding rotation and factor membership fixed.
    loo = []
    for j, c in enumerate(cols):
        ii = np.where(F[:, j])[0]
        for omit in ii:
            jj = ii[ii != omit]
            w = L[jj, j] / (1 - L[jj, j] ** 2)
            zz = (Z[jj] * w[:, None]).sum(0) / np.abs(w).sum()
            zz = (zz - zz.mean()) / zz.std()
            loo.append([c, x.index[omit], np.corrcoef(z[:, j], zz)[0, 1]])
    tables['array_sensitivity'] = pd.DataFrame(loo, columns=['factor', 'omitted_id', 'array_correlation'])
    summary = {'n': N, 'statements': M, 'threshold': float(threshold), 'eigenvalues': ev[:8].tolist(), 'variance_percent': float((L * L).sum() / N * 100), 'factor_variance': ((L * L).sum(0) / N * 100).tolist(), 'defining_counts': ns, 'status_counts': lf.status.value_counts().to_dict(), 'reliability_assumption': 0.8, 'SE_factor_z': se.tolist(), 'solutions': solutions, 'loo_min': float(min((v[2] for v in loo)))}
    # Account explicitly for single-significant sorts that fail the dominance criterion.
    for row in solutions:
        row['single_significant_not_defining'] = N - row['defined'] - row['multiple_significant'] - row['no_significant']
    tables['alternative_solutions'] = pd.DataFrame(solutions)
    return (tables, summary)

def make_summary(summary):
    # Percentages are stored in percentage points: 70.28 means 70.28%, not 7,028%.
    rows = [
        ('n', summary['n'], 'Number of main-sample Q sorts'),
        ('statements', summary['statements'], 'Statements in each Q sort'),
        ('retained_factors', 4, 'Four-factor solution retained from the supplied analysis'),
        ('variance_percent', summary['variance_percent'], 'Cumulative explained variance, in percentage points'),
        ('loading_threshold', summary['threshold'], 'Absolute loading threshold, two-sided p < .01'),
        ('defining', summary['status_counts'].get('defining',0), 'Participants with a defining sort'),
        ('confounded', summary['status_counts'].get('confounded',0), 'Participants with multiple significant loadings'),
        ('unassigned', summary['status_counts'].get('unassigned',0), 'Participants without a significant loading'),
        ('not_defining', summary['status_counts'].get('not_defining',0), 'One significant loading but dominance criterion not met'),
        ('single_sort_reliability', .8, 'Reliability assumption used to calculate standard errors'),
        ('minimum_array_correlation', summary['loo_min'], 'Minimum leave-one-defining-sort-out correlation, with rotation and membership fixed'),
    ]
    names = ['Expertise-led distributed checking', 'Participatory scrutiny and shared responsibility', 'Traceable delegation and bounded responsibility', 'Coordinated proportional checking']
    for j in range(4):
        f = f'F{j+1}'
        rows.extend([(f+'_label', names[j], 'Interpretive label from the original four-factor solution; reassess after changing data'),
                     (f+'_defining_n', summary['defining_counts'][j], 'Defining-sort count'),
                     (f+'_variance_percent', summary['factor_variance'][j], 'Rotated explained variance, in percentage points'),
                     (f+'_SE_z', summary['SE_factor_z'][j], 'Standard error of the factor z scores')])
    rows.extend([
        ('read_first', RESULT_MAP['factor_loadings'], 'Find a participant_id and read the loadings, defining flags and status.'),
        ('read_next', RESULT_MAP['factor_arrays'], 'Join statement_id to Statements in Data.xlsx. A factor rank is an array position, not an individual raw sort.'),
        ('distinguishing', '* / **', 'p < .05 / p < .01 against every other factor; blank means the criterion was not met.'),
        ('pairwise_tests', 'unadjusted', 'Two-sided normal-approximation p values, without multiplicity correction.'),
        ('refresh', 'python analysis.py', 'Rerun the script after editing data; Excel does not automatically repeat the factor analysis.'),
    ])
    return pd.DataFrame(rows, columns=['metric','value','explanation'])

def format_results(tables, summary):
    frames = {'summary': make_summary(summary)}
    for key in RESULT_MAP:
        if key == 'summary':
            continue
        df = tables[key].copy()
        if key == 'alternative_solutions':
            df['defining_counts'] = df['defining_counts'].map(lambda v: json.dumps(v))
        frames[key] = df
    return {RESULT_MAP[key]: frame for key, frame in frames.items()}

def write_results(frames):
    # Write to a temporary file first, so an interrupted run does not destroy Results.xlsx.
    target = ROOT / 'Results.xlsx'
    temporary = ROOT / '.Results.tmp.xlsx'
    with pd.ExcelWriter(temporary, engine='openpyxl') as writer:
        for name, frame in frames.items():
            frame.to_excel(writer, sheet_name=name, index=False)
            sheet = writer.sheets[name]
            sheet.sheet_view.showGridLines = False
            sheet.freeze_panes = 'B2'
            sheet.auto_filter.ref = sheet.dimensions
            for cell in sheet[1]:
                cell.font = Font(name='Arial', size=11, bold=True, color='000000')
                cell.fill = PatternFill('solid', fgColor='E6E6E6')
                cell.alignment = Alignment(wrap_text=True, vertical='center')
            sheet.row_dimensions[1].height = 36
            widths = []
            for j, col in enumerate(frame.columns, 1):
                width = 76 if col == 'explanation' else 48 if col == 'value' else 34 if col == 'metric' else max(14, min(30, len(col)+2))
                widths.append(width)
                sheet.column_dimensions[get_column_letter(j)].width = width
            for row in sheet.iter_rows(min_row=2):
                lines = 1
                for cell, width in zip(row, widths):
                    cell.font = Font(name='Arial', size=11, color='000000')
                    cell.alignment = Alignment(wrap_text=True, vertical='top')
                    if isinstance(cell.value, float):
                        cell.number_format = '0.00E+00' if frame.columns[cell.column-1] == 'p' else '0.0000'
                    text = str(cell.value or '')
                    weighted_length = sum(2 if ord(ch)>255 else 1 for ch in text)
                    lines = max(lines, math.ceil(weighted_length/max(8,width-3)))
                sheet.row_dimensions[row[0].row].height = max(23, 16*lines+8)
    try:
        temporary.replace(target)
    except PermissionError as exc:
        raise PermissionError('Close Results.xlsx in Excel, then rerun the script.') from exc

def draw_figures(tables):
    # All figure inputs come from the analysis or the fixed sorting-grid specification.
    folder = ROOT / 'figures'
    folder.mkdir(exist_ok=True)
    available = {font.name for font in font_manager.fontManager.ttflist}
    preferred = ['Noto Sans CJK SC','Microsoft YaHei','SimHei','Arial Unicode MS','DejaVu Sans']
    plt.rcParams.update({'font.family':[f for f in preferred if f in available], 'font.size':11,
                         'svg.fonttype':'path', 'axes.spines.top':False, 'axes.spines.right':False,
                         'axes.unicode_minus':False})
    # English plot labels make figures portable even on computers without Chinese fonts.
    eigen = tables['eigenvalues']
    fig, ax = plt.subplots(figsize=(6.4,3.5), layout='constrained')
    ax.plot(eigen.component[:12], eigen.eigenvalue[:12], '-o',color='black',markersize=4)
    ax.axhline(1,color='0.6',linestyle='--',linewidth=.8)
    ax.set(xlabel='Component',ylabel='Eigenvalue',xticks=range(1,13),xlim=(.7,12.3))
    fig.savefig(folder/'scree_plot.svg'); plt.close(fig)
    arr = tables['factor_arrays']
    ranks = arr[[f'F{i}_rank' for i in range(1,5)]].to_numpy()
    fig, axs = plt.subplots(1,2,figsize=(8.2,7),layout='constrained')
    for panel, ax in enumerate(axs):
        start = panel*20
        matrix = ranks[start:start+20]
        ax.imshow(matrix,cmap='Greys',vmin=-4,vmax=4,aspect='auto')
        ax.set(xticks=range(4),xticklabels=['F1','F2','F3','F4'],yticks=range(20),yticklabels=arr.statement_id[start:start+20])
        ax.tick_params(length=0)
        for row in range(20):
            for col in range(4):
                value=int(matrix[row,col])
                ax.text(col,row,f'{value:+d}' if value else '0',ha='center',va='center',color='white' if value>=1 else 'black',fontsize=10)
        for spine in ax.spines.values(): spine.set_visible(False)
    fig.savefig(folder/'factor_arrays.svg'); plt.close(fig)
    # Match manuscript Figure 2: top-aligned cards, scores above, capacities below.
    with plt.rc_context({'font.family':'DejaVu Sans', 'font.size':9,
                         'svg.fonttype':'none', 'axes.linewidth':.6,
                         'savefig.facecolor':'white'}):
        fig, ax = plt.subplots(figsize=(6.5,3.3))
        ax.set(xlim=(-.5,8.5),ylim=(0,11.8))
        ax.axis('off')
        counts = [2,3,4,6,10,6,4,3,2]
        for i, count in enumerate(counts):
            ax.text(i,11.2,f'{i-4:+d}' if i!=4 else '0',ha='center',va='center',weight='bold',fontsize=10)
            for j in range(count):
                ax.add_patch(plt.Rectangle((i-.45,9.7-j*.88),.90,.82,
                                          facecolor='.94' if i%2==0 else 'white',
                                          edgecolor='.25',lw=.6))
            ax.text(i,10.2-count*.88,str(count),ha='center',va='center',fontsize=8,color='.3')
        ax.text(-.45,.25,'Most disagree',ha='left',va='center',fontsize=9)
        ax.text(8.45,.25,'Most agree',ha='right',va='center',fontsize=9)
        fig.subplots_adjust(0,0,1,1)
        fig.savefig(folder/'sorting_grid.svg',bbox_inches='tight',pad_inches=.035)
        plt.close(fig)

def main():
    x, _ = load_data()
    tables, summary = analyse(x)
    frames = format_results(tables, summary)
    write_results(frames)
    draw_figures(tables)
    print('Done: refreshed Results.xlsx and three SVG figures; Data.xlsx was not modified.')
    print(f"N={summary['n']}; variance={summary['variance_percent']:.4f}%; defining={summary['defining_counts']}")

if __name__ == '__main__':
    try:
        main()
    except (ValueError, KeyError, PermissionError, FileNotFoundError) as error:
        print('Unable to complete: '+str(error),file=sys.stderr)
        sys.exit(1)
